﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WWTEncoding.Extensions
{
    public static class CharExtentions
    {
        public static bool IsVowel(this char character)
        {
            return new[] { 'a', 'e', 'i', 'o', 'u' }.Contains(char.ToLower(character));
        }
    }
}
