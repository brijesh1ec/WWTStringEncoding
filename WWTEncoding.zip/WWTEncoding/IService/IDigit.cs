﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WWTEncoding.IService
{
    interface IDigit
    {
        public bool IsNumbers(char ch);
        public string ReverseNumber(StringBuilder stringBuilder);
    }
}
