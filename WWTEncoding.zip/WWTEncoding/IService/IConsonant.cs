﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WWTEncoding.IService
{
    interface IConsonant
    {
        public bool IsConsonant(char ch);
        public string ReplaceConsonants(char s);       
    }
}
