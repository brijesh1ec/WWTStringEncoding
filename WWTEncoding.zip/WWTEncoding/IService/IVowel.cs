﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WWTEncoding.IService
{
    interface IVowel
    {
        public Dictionary<char, int> LoadVowel();
        public bool IsVowel(char ch);
    }
}
