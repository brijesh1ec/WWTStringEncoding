﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WWTEncoding.IService;

namespace WWTEncoding.Service
{
    internal class Digit : IDigit
    {
        static StringBuilder stringBuilderNumber = new StringBuilder();
        public bool IsNumbers(char ch)
        {
            return CheckNumbers(ch);
        }

        private bool CheckNumbers(char ch)
        {
            bool isNumber = false;
            var lc = char.IsNumber(ch);

            if (lc)
            {
                isNumber = true;
            }
            return isNumber;
        }

        public string ReverseNumber(StringBuilder stringBuilder)
        {
            char[] charArray = null;

            if (stringBuilder != null && stringBuilder.Length > 0)
            {
                charArray = stringBuilder.ToString().ToCharArray();
                Array.Reverse(charArray);
            }
            return new string(charArray);
        }



    }    
}
