﻿using System;
using System.Collections.Generic;
using System.Text;
using WWTEncoding.IService;

namespace WWTEncoding.Service
{
    internal class Consonant : IConsonant
    {
        private IVowel vowel;

        public Consonant(IVowel vowel)
        {
            this.vowel = vowel;
        }

        public bool IsConsonant(char ch)
        {
            bool isConsonant = false;
            var lc = char.ToLowerInvariant(ch);
            if ((lc == 'a' || lc == 'e' || lc == 'i' || lc == 'o' || lc == 'u') == false && (ch >= 97 && ch <= 122))
                return isConsonant = true;

            return isConsonant;
        }



        public string ReplaceConsonants(char s)
        {
            char cv = default(char);
            // Start traversing the string  
            if (!this.vowel.IsVowel(s))
            {
                // previous immediate alphabet  
                s = (char)(s - 1);

                // if previous immediate alphabet is vowel,  
                // than take previous 2nd immediate alphabet  
                // (since no two vowels occurs consecutively  
                // in alphabets) hence no further  
                // checking is required            

                if (this.vowel.IsVowel(s))
                {
                    var vowels = this.vowel.LoadVowel();
                    //var c = (char)Int16.Parse(Convert.ToString(vowels[s]), System.Globalization.NumberStyles.HexNumber);
                    //s = (char)(vowels[s]);
                    cv = char.Parse(vowels[s].ToString());
                }
                else
                {
                    cv = s;
                }
            }
            return String.Join(string.Empty, cv);
        }
    }
}
