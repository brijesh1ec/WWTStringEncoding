﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WWTEncoding.IService;

namespace WWTEncoding.Service
{
    internal class Vowel : IVowel
    {
        public static Dictionary<char, int> vowelValuePairs = new Dictionary<char, int>();
        public bool IsVowel(char character)
        {
            return new[] { 'a', 'e', 'i', 'o', 'u' }.Contains(char.ToLower(character));
        }

        public Dictionary<char, int> LoadVowel()
        {
            if (vowelValuePairs != null && vowelValuePairs.Count > 0)
                return vowelValuePairs;
            else
                return getVowels();
        }

        private static Dictionary<char, int> getVowels()
        {
            // a-> 1, e-> 2, i-> 3, o-> 4, and u -> 5
            vowelValuePairs.Add('a', 1);
            vowelValuePairs.Add('e', 2);
            vowelValuePairs.Add('i', 3);
            vowelValuePairs.Add('o', 4);
            vowelValuePairs.Add('u', 5);
            return vowelValuePairs;
        }
    }

}
