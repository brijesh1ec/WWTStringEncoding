﻿using System;
using System.Collections.Generic;
using System.Text;
using WWTEncoding.IService;
using WWTEncoding.Service;

namespace WWTEncoding
{
    class Program
    {   

        static void Main(string[] args)
        {
            Console.WriteLine("Please enter input string");
            var message = Console.ReadLine();           
            var encodedstring = new EncoderProcessor().Encode(message);
            Console.WriteLine("Input string is {0} Please collect encoded string {1}", message, encodedstring);
        }  
        
    }

    internal class EncoderProcessor
    {
        #region DataMemberRegion
        static Dictionary<char, int> vowelValuePairs = new Dictionary<char, int>();
        static StringBuilder stringBuilderNumber = new StringBuilder();
        static StringBuilder stringBuilder = new StringBuilder();
        public static char SPACE = ' ';
        public const char charY = 'y';
        public static IVowel vowel;
        public static IDigit digit;
        public static IConsonant consonant;


        #endregion

        private static void LoadData(IVowel vowels, IDigit digits, IConsonant consonants)
        {
            vowel = vowels;
            digit = digits;
            consonant = consonants;
        }

        private static Dictionary<char, int> LoadData()
        {
            return vowelValuePairs = vowel.LoadVowel();
        }

        private static bool IsVowel(char c)
        {
            return vowel.IsVowel(c);
        }

        public string Encode(string message)
        {

            vowel = new Vowel();
            digit = new Digit();
            consonant = new Consonant(vowel);
            LoadData(vowel, digit, consonant);
            LoadData();
            var result = string.Empty;

            if (!string.IsNullOrEmpty(message) && message.Length > 1)
            {
                var vowels = vowelValuePairs;
                foreach (var ch in message.ToLower())
                {
                    if (IsVowel(ch))
                    {
                        if (vowels.ContainsKey(ch))
                        {
                            stringBuilder = stringBuilder.Append($"{vowels[ch]}");
                        }
                    }
                    else if (digit.IsNumbers(ch))
                    {
                        stringBuilderNumber.Append(ch);
                    }
                    else if (!char.IsLetterOrDigit(ch))
                    {
                        if (Common.isSpace(ch) || ch == charY)
                        {
                            var sy = Common.Space(ch);
                            stringBuilder.Append(sy);
                        }
                        else
                            stringBuilder.Append(ch);
                    }
                    else if (consonant.IsConsonant(ch))
                    {
                        Common.AppendNumber(stringBuilderNumber, digit, stringBuilder);
                        var consonent = consonant.ReplaceConsonants(ch);
                        stringBuilder.Append(Convert.ToChar(Convert.ToChar(consonent)));
                    }
                }
            }
            else
            {
                Console.WriteLine("Invalid input string {0}", message);
            }
            if (stringBuilderNumber != null && stringBuilderNumber.Length > 0)
            {
                Common.AppendNumber(stringBuilderNumber, digit, stringBuilder);
            }
            return stringBuilder.ToString();
        }

    }
    internal class Common
    {
        public static char SPACE = ' ';
        public static bool isSpace(char c)
        {
            return SPACE == c;
        }

        public static char Space(char c)
        {
            var sy = char.IsWhiteSpace(c) ? 'y' : ' ';
            return sy;
        }

        public static void AppendNumber(StringBuilder sb, IDigit digits, StringBuilder stringBuilder)
        {
            if (sb != null && sb.Length > 0)
            {
                var str1 = digits.ReverseNumber(sb);
                stringBuilder.Append(str1);
                sb.Clear();
            }
        }
    }
}
